[![Build Status](https://travis-ci.org/elvircrn/bcomp.svg?branch=master)](https://travis-ci.org/elvircrn/bcomp)

# TODO
* Implement functions
  * Implement function calls

* Implement printf

* Datu liniju za provjeru dodajte iza svih UnaryExpr i PostfixExpr za operatore inkrementiranja i dekrementiranja.

* Implemented IsAssignable
  * Check if IsAssignable properly handles unary increment/decrement

* Napisite funkciju koja provjerava da li je goto labela vec definisana i promijenite pravilo Label da to testira.

* Po uzoru na ADD, lako realizujte generisanje asemblerskog koda za AND, OR, XOR i MUL. Probajte i SUB (pazite na nekomutativnost).

* Nice to have 
  * Make parser stop using standard output 
  * Get node id from string position

# Known bugs
