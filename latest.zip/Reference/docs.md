# int ElemPos(int position, int elemnum) 

## position

## elemnum

## Returns
Position of the next element in the ParseTree



# GetElemName

