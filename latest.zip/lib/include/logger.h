/*
 *  Distributed under the MIT License (See accompanying file /LICENSE )
 */
#ifndef LOG_HPP
#define LOG_HPP

#endif  // LOG_HPP
