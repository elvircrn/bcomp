#include "BArgument.h"
bompiler::BArgument::BArgument(bompiler::PNode *_node) : node(_node) {

}
bompiler::BArgument::BArgument() : node(nullptr) {

}
